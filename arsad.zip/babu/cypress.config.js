const { defineConfig } = require('cypress');

module.exports = defineConfig({
  e2e: {
    baseUrl: 'http://localhost:3000',
    supportFile: 'tests/e2e/support/e2e.js',
    specPattern: 'tests/e2e/**/*.cy.js',
    videosFolder: 'tests/reports/videos',
    screenshotsFolder: 'tests/reports/screenshots',
    video: true,
    screenshot: true,
    screenshotOnRunFailure: true,
    viewportWidth: 1280,
    viewportHeight: 720,
    defaultCommandTimeout: 10000,
    requestTimeout: 15000,
    responseTimeout: 15000,
    pageLoadTimeout: 30000,
    watchForFileChanges: true,
    retries: {
      runMode: 2,
      openMode: 0
    },
    env: {
      coverage: true
    }
  },

  component: {
    devServer: {
      framework: 'create-react-app',
      bundler: 'webpack',
    },
  },

  // Mobile testing configurations
  projects: [
    {
      name: 'desktop',
      testIsolation: true,
      viewportWidth: 1280,
      viewportHeight: 720,
    },
    {
      name: 'tablet',
      testIsolation: true,
      viewportWidth: 768,
      viewportHeight: 1024,
    },
    {
      name: 'mobile',
      testIsolation: true,
      viewportWidth: 375,
      viewportHeight: 667,
    }
  ]
});