/**
 * Real-Time Stock Ticker Application
 * Phase 4 - Enhanced Version with Advanced Features
 * 
 * Features:
 * - Real-time WebSocket data streaming
 * - Interactive charts with Chart.js
 * - Responsive design with mobile support
 * - Local storage persistence
 * - Error handling and retry logic
 * - Performance optimizations
 * - Security enhancements
 */

class StockTicker {
    constructor() {
        this.stocks = new Map();
        this.charts = new Map();
        this.wsConnections = new Map();
        this.apiKey = 'demo'; // Replace with your actual API key
        this.updateInterval = 30000; // 30 seconds
        this.maxRetries = 3;
        this.retryDelay = 2000;

        // Performance monitoring
        this.performanceMetrics = {
            apiCalls: 0,
            wsConnections: 0,
            errors: 0,
            lastUpdate: Date.now()
        };

        // Initialize the application
        this.init();
    }

    async init() {
        try {
            this.loadFromStorage();
            this.bindEvents();
            this.startUpdateTimer();
            this.updateMarketStatus();
            this.loadPopularStocks();

            // Initialize with some default stocks if none exist
            if (this.stocks.size === 0) {
                await this.addStock('AAPL');
                await this.addStock('GOOGL');
                await this.addStock('TSLA');
            }

            console.log('Stock Ticker initialized successfully');
        } catch (error) {
            console.error('Error initializing Stock Ticker:', error);
            this.showError('Failed to initialize application');
        }
    }

    bindEvents() {
        // Stock search form
        const searchForm = document.getElementById('stock-search-form');
        const symbolInput = document.getElementById('stock-symbol-input');

        searchForm?.addEventListener('submit', async (e) => {
            e.preventDefault();
            const symbol = symbolInput.value.trim().toUpperCase();
            if (symbol) {
                await this.addStock(symbol);
                symbolInput.value = '';
            }
        });

        // Input validation and formatting
        symbolInput?.addEventListener('input', (e) => {
            e.target.value = e.target.value.toUpperCase().replace(/[^A-Z]/g, '');
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            // Ctrl/Cmd + Enter to add stock
            if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                searchForm?.dispatchEvent(new Event('submit'));
            }

            // Escape to clear input
            if (e.key === 'Escape') {
                symbolInput.value = '';
                symbolInput.blur();
            }
        });

        // Handle page visibility changes for performance
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                this.pauseUpdates();
            } else {
                this.resumeUpdates();
            }
        });

        // Handle online/offline events
        window.addEventListener('online', () => {
            this.resumeUpdates();
            this.showSuccess('Connection restored');
        });

        window.addEventListener('offline', () => {
            this.pauseUpdates();
            this.showError('Connection lost. Data updates paused.');
        });
    }

    async addStock(symbol, retryCount = 0) {
        try {
            if (this.stocks.has(symbol)) {
                this.showError(`${symbol} is already being tracked`);
                return;
            }

            this.showLoading(`Adding ${symbol}...`);

            // Validate stock symbol first
            const stockData = await this.fetchStockData(symbol);
            if (!stockData || stockData.error) {
                throw new Error(stockData?.error || 'Invalid stock symbol');
            }

            // Add to stocks map
            this.stocks.set(symbol, {
                ...stockData,
                id: this.generateId(),
                addedAt: Date.now(),
                history: [stockData.price],
                lastUpdate: Date.now()
            });

            // Create UI elements
            this.createStockCard(symbol, stockData);
            this.initializeChart(symbol, stockData);
            this.updateTickerMarquee();
            this.updateStats();
            this.saveToStorage();

            // Start real-time updates for this stock
            this.startRealtimeUpdates(symbol);

            this.clearMessages();
            this.showSuccess(`${symbol} added successfully`);

        } catch (error) {
            console.error(`Error adding stock ${symbol}:`, error);

            if (retryCount < this.maxRetries) {
                console.log(`Retrying ${symbol} (${retryCount + 1}/${this.maxRetries})`);
                await this.delay(this.retryDelay);
                return this.addStock(symbol, retryCount + 1);
            }

            this.showError(error.message || `Failed to add ${symbol}`);
            this.performanceMetrics.errors++;
        }
    }

    async fetchStockData(symbol) {
        try {
            this.performanceMetrics.apiCalls++;

            // Simulate API call with realistic data
            // In production, replace with actual API calls to Alpha Vantage, Finnhub, etc.
            const mockData = await this.getMockStockData(symbol);

            if (!mockData) {
                throw new Error('Stock not found');
            }

            return mockData;

        } catch (error) {
            console.error(`Error fetching data for ${symbol}:`, error);
            throw error;
        }
    }

    async getMockStockData(symbol) {
        // Simulate API delay
        await this.delay(Math.random() * 1000 + 500);

        const stockDatabase = {
            'AAPL': { name: 'Apple Inc.', sector: 'Technology', basePrice: 175 },
            'GOOGL': { name: 'Alphabet Inc.', sector: 'Technology', basePrice: 125 },
            'TSLA': { name: 'Tesla Inc.', sector: 'Automotive', basePrice: 250 },
            'MSFT': { name: 'Microsoft Corporation', sector: 'Technology', basePrice: 350 },
            'AMZN': { name: 'Amazon.com Inc.', sector: 'E-commerce', basePrice: 140 },
            'NVDA': { name: 'NVIDIA Corporation', sector: 'Technology', basePrice: 450 },
            'META': { name: 'Meta Platforms Inc.', sector: 'Technology', basePrice: 300 },
            'NFLX': { name: 'Netflix Inc.', sector: 'Entertainment', basePrice: 400 },
            'AMD': { name: 'Advanced Micro Devices', sector: 'Technology', basePrice: 120 },
            'CRM': { name: 'Salesforce Inc.', sector: 'Technology', basePrice: 200 }
        };

        const stockInfo = stockDatabase[symbol];
        if (!stockInfo) {
            return null;
        }

        // Generate realistic price with volatility
        const volatility = (Math.random() - 0.5) * 0.1; // ±5% volatility
        const price = stockInfo.basePrice * (1 + volatility);
        const change = (Math.random() - 0.5) * 10; // ±$5 change
        const changePercent = (change / price) * 100;

        return {
            symbol,
            name: stockInfo.name,
            price: parseFloat(price.toFixed(2)),
            change: parseFloat(change.toFixed(2)),
            changePercent: parseFloat(changePercent.toFixed(2)),
            volume: Math.floor(Math.random() * 10000000) + 1000000,
            marketCap: Math.floor(Math.random() * 1000000000000) + 100000000000,
            sector: stockInfo.sector,
            dayHigh: parseFloat((price * 1.05).toFixed(2)),
            dayLow: parseFloat((price * 0.95).toFixed(2)),
            timestamp: Date.now()
        };
    }

    createStockCard(symbol, stockData) {
        const stockGrid = document.getElementById('stock-grid');
        if (!stockGrid) return;

        // Remove loading message if present
        const loading = stockGrid.querySelector('.loading');
        if (loading) {
            loading.remove();
        }

        const card = document.createElement('div');
        card.className = 'stock-card';
        card.id = `stock-${symbol}`;
        card.setAttribute('data-symbol', symbol);

        const changeClass = stockData.change >= 0 ? 'positive' : 'negative';
        const changeArrow = stockData.change >= 0 ? 'fas fa-arrow-up' : 'fas fa-arrow-down';

        card.innerHTML = `
            <div class="stock-header">
                <div>
                    <div class="stock-symbol">${symbol}</div>
                    <div class="stock-name">${stockData.name}</div>
                </div>
                <button class="remove-btn" onclick="stockTicker.removeStock('${symbol}')" 
                        title="Remove ${symbol}" aria-label="Remove ${symbol} from tracker">
                    <i class="fas fa-times"></i>
                </button>
            </div>

            <div class="stock-price">$${stockData.price.toFixed(2)}</div>

            <div class="stock-change ${changeClass}">
                <i class="${changeArrow} change-arrow"></i>
                <span>$${stockData.change.toFixed(2)} (${stockData.changePercent.toFixed(2)}%)</span>
            </div>

            <div class="stock-details" style="margin-top: 1rem; font-size: 0.875rem; color: var(--text-secondary);">
                <div style="display: flex; justify-content: space-between; margin: 0.25rem 0;">
                    <span>Volume:</span>
                    <span>${this.formatNumber(stockData.volume)}</span>
                </div>
                <div style="display: flex; justify-content: space-between; margin: 0.25rem 0;">
                    <span>Day High:</span>
                    <span>$${stockData.dayHigh.toFixed(2)}</span>
                </div>
                <div style="display: flex; justify-content: space-between; margin: 0.25rem 0;">
                    <span>Day Low:</span>
                    <span>$${stockData.dayLow.toFixed(2)}</span>
                </div>
            </div>

            <div class="chart-container">
                <canvas class="chart-canvas" id="chart-${symbol}" 
                        aria-label="Price chart for ${symbol}"></canvas>
            </div>
        `;

        stockGrid.appendChild(card);

        // Add entrance animation
        requestAnimationFrame(() => {
            card.style.transform = 'translateY(20px)';
            card.style.opacity = '0';
            card.style.transition = 'all 0.3s ease';

            requestAnimationFrame(() => {
                card.style.transform = 'translateY(0)';
                card.style.opacity = '1';
            });
        });
    }

    initializeChart(symbol, stockData) {
        const canvas = document.getElementById(`chart-${symbol}`);
        if (!canvas) return;

        const ctx = canvas.getContext('2d');

        // Generate initial chart data
        const chartData = this.generateChartData(stockData);

        const chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: chartData.labels,
                datasets: [{
                    label: symbol,
                    data: chartData.data,
                    borderColor: stockData.change >= 0 ? '#22c55e' : '#ef4444',
                    backgroundColor: stockData.change >= 0 
                        ? 'rgba(34, 197, 94, 0.1)' 
                        : 'rgba(239, 68, 68, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4,
                    pointRadius: 0,
                    pointHoverRadius: 6,
                    pointHoverBorderWidth: 2,
                    pointHoverBackgroundColor: '#ffffff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff',
                        borderColor: '#333333',
                        borderWidth: 1,
                        displayColors: false,
                        callbacks: {
                            label: function(context) {
                                return `$${context.parsed.y.toFixed(2)}`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        display: false,
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        display: false,
                        grid: {
                            display: false
                        },
                        beginAtZero: false
                    }
                },
                animation: {
                    duration: 750,
                    easing: 'easeInOutQuart'
                }
            }
        });

        this.charts.set(symbol, chart);
    }

    generateChartData(stockData) {
        const dataPoints = 20;
        const labels = [];
        const data = [];
        const basePrice = stockData.price;

        for (let i = dataPoints - 1; i >= 0; i--) {
            const time = new Date(Date.now() - (i * 30000));
            labels.push(time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));

            // Generate realistic price movement
            const volatility = (Math.random() - 0.5) * 0.02;
            const price = basePrice * (1 + volatility * (dataPoints - i) / dataPoints);
            data.push(parseFloat(price.toFixed(2)));
        }

        return { labels, data };
    }

    async removeStock(symbol) {
        try {
            // Confirmation dialog
            if (!confirm(`Remove ${symbol} from tracker?`)) {
                return;
            }

            // Stop real-time updates
            this.stopRealtimeUpdates(symbol);

            // Remove from data structures
            this.stocks.delete(symbol);

            // Destroy chart
            const chart = this.charts.get(symbol);
            if (chart) {
                chart.destroy();
                this.charts.delete(symbol);
            }

            // Remove UI element with animation
            const card = document.getElementById(`stock-${symbol}`);
            if (card) {
                card.style.transform = 'translateX(-100%)';
                card.style.opacity = '0';
                card.style.transition = 'all 0.3s ease';

                setTimeout(() => {
                    card.remove();

                    // Show placeholder if no stocks remain
                    if (this.stocks.size === 0) {
                        const stockGrid = document.getElementById('stock-grid');
                        if (stockGrid) {
                            stockGrid.innerHTML = `
                                <div class="loading">
                                    <div class="loading-spinner"></div>
                                    Add your first stock to start tracking
                                </div>
                            `;
                        }
                    }
                }, 300);
            }

            this.updateTickerMarquee();
            this.updateStats();
            this.saveToStorage();

            this.showSuccess(`${symbol} removed successfully`);

        } catch (error) {
            console.error(`Error removing stock ${symbol}:`, error);
            this.showError(`Failed to remove ${symbol}`);
        }
    }

    startRealtimeUpdates(symbol) {
        // Simulate real-time updates
        const updateStock = async () => {
            try {
                const stockData = this.stocks.get(symbol);
                if (!stockData) return;

                const newData = await this.getMockStockData(symbol);
                if (newData) {
                    // Update stock data
                    const updatedStock = { ...stockData, ...newData, lastUpdate: Date.now() };
                    updatedStock.history.push(newData.price);

                    // Keep only last 20 data points for performance
                    if (updatedStock.history.length > 20) {
                        updatedStock.history = updatedStock.history.slice(-20);
                    }

                    this.stocks.set(symbol, updatedStock);

                    // Update UI
                    this.updateStockCard(symbol, newData);
                    this.updateChart(symbol, newData);
                }
            } catch (error) {
                console.error(`Error updating ${symbol}:`, error);
            }
        };

        // Initial update
        updateStock();

        // Schedule periodic updates
        const intervalId = setInterval(updateStock, this.updateInterval);
        this.wsConnections.set(symbol, intervalId);
    }

    stopRealtimeUpdates(symbol) {
        const intervalId = this.wsConnections.get(symbol);
        if (intervalId) {
            clearInterval(intervalId);
            this.wsConnections.delete(symbol);
        }
    }

    updateStockCard(symbol, stockData) {
        const card = document.getElementById(`stock-${symbol}`);
        if (!card) return;

        const priceElement = card.querySelector('.stock-price');
        const changeElement = card.querySelector('.stock-change');
        const detailsElements = card.querySelectorAll('.stock-details div span:last-child');

        if (priceElement) {
            // Animate price change
            const oldPrice = parseFloat(priceElement.textContent.replace('$', ''));
            const newPrice = stockData.price;

            if (oldPrice !== newPrice) {
                priceElement.style.color = newPrice > oldPrice ? '#22c55e' : '#ef4444';
                setTimeout(() => {
                    priceElement.style.color = '';
                }, 1000);
            }

            priceElement.textContent = `$${newPrice.toFixed(2)}`;
        }

        if (changeElement) {
            const changeClass = stockData.change >= 0 ? 'positive' : 'negative';
            const changeArrow = stockData.change >= 0 ? 'fas fa-arrow-up' : 'fas fa-arrow-down';

            changeElement.className = `stock-change ${changeClass}`;
            changeElement.innerHTML = `
                <i class="${changeArrow} change-arrow"></i>
                <span>$${stockData.change.toFixed(2)} (${stockData.changePercent.toFixed(2)}%)</span>
            `;
        }

        // Update details
        if (detailsElements[0]) detailsElements[0].textContent = this.formatNumber(stockData.volume);
        if (detailsElements[1]) detailsElements[1].textContent = `$${stockData.dayHigh.toFixed(2)}`;
        if (detailsElements[2]) detailsElements[2].textContent = `$${stockData.dayLow.toFixed(2)}`;
    }

    updateChart(symbol, stockData) {
        const chart = this.charts.get(symbol);
        if (!chart) return;

        const stock = this.stocks.get(symbol);
        if (!stock) return;

        // Update chart data
        const now = new Date();
        chart.data.labels.push(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
        chart.data.datasets[0].data.push(stockData.price);

        // Keep only last 20 data points
        if (chart.data.labels.length > 20) {
            chart.data.labels.shift();
            chart.data.datasets[0].data.shift();
        }

        // Update colors based on current trend
        chart.data.datasets[0].borderColor = stockData.change >= 0 ? '#22c55e' : '#ef4444';
        chart.data.datasets[0].backgroundColor = stockData.change >= 0 
            ? 'rgba(34, 197, 94, 0.1)' 
            : 'rgba(239, 68, 68, 0.1)';

        chart.update('none'); // No animation for better performance
    }

    updateTickerMarquee() {
        const tickerContent = document.getElementById('ticker-content');
        if (!tickerContent || this.stocks.size === 0) return;

        const tickerHTML = Array.from(this.stocks.entries()).map(([symbol, data]) => {
            const changeClass = data.change >= 0 ? 'positive' : 'negative';
            const changeSign = data.change >= 0 ? '+' : '';

            return `
                <div class="ticker-item">
                    <span class="ticker-symbol">${symbol}</span>
                    <span class="ticker-price">$${data.price.toFixed(2)}</span>
                    <span class="ticker-change ${changeClass}">
                        ${changeSign}${data.changePercent.toFixed(2)}%
                    </span>
                </div>
            `;
        }).join('');

        tickerContent.innerHTML = tickerHTML;
    }

    updateStats() {
        const activeStocksElement = document.getElementById('active-stocks');
        const lastUpdateElement = document.getElementById('last-update');

        if (activeStocksElement) {
            activeStocksElement.textContent = this.stocks.size;
        }

        if (lastUpdateElement) {
            const now = new Date();
            lastUpdateElement.textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        }

        this.performanceMetrics.lastUpdate = Date.now();
    }

    updateMarketStatus() {
        const now = new Date();
        const hour = now.getHours();
        const isWeekend = now.getDay() === 0 || now.getDay() === 6;
        const isMarketHours = hour >= 9 && hour < 16 && !isWeekend;

        const marketStatusElement = document.getElementById('market-status');
        const nyseStatusElement = document.getElementById('nyse-status');
        const nasdaqStatusElement = document.getElementById('nasdaq-status');

        const status = isMarketHours ? 'Open' : 'Closed';
        const statusClass = isMarketHours ? 'status-open' : 'status-closed';

        if (marketStatusElement) marketStatusElement.textContent = status;
        if (nyseStatusElement) {
            nyseStatusElement.textContent = status;
            nyseStatusElement.className = `status-indicator ${statusClass}`;
        }
        if (nasdaqStatusElement) {
            nasdaqStatusElement.textContent = status;
            nasdaqStatusElement.className = `status-indicator ${statusClass}`;
        }
    }

    async loadPopularStocks() {
        const popularSymbols = ['AAPL', 'GOOGL', 'TSLA', 'MSFT', 'AMZN'];
        const popularStocksContainer = document.getElementById('popular-stocks');

        if (!popularStocksContainer) return;

        for (const symbol of popularSymbols) {
            try {
                const data = await this.getMockStockData(symbol);
                if (data) {
                    const item = popularStocksContainer.querySelector(`[data-symbol="${symbol}"]`) ||
                                popularStocksContainer.children[popularSymbols.indexOf(symbol)];
                    if (item) {
                        const priceElement = item.querySelector('.watchlist-price');
                        if (priceElement) {
                            priceElement.textContent = `$${data.price.toFixed(2)}`;
                        }
                        item.setAttribute('data-symbol', symbol);
                        item.style.cursor = 'pointer';
                        item.onclick = () => this.addStock(symbol);
                    }
                }
            } catch (error) {
                console.error(`Error loading popular stock ${symbol}:`, error);
            }
        }
    }

    startUpdateTimer() {
        const updateNextUpdateDisplay = () => {
            const nextUpdateElement = document.getElementById('next-update');
            if (nextUpdateElement) {
                const seconds = Math.ceil((this.performanceMetrics.lastUpdate + this.updateInterval - Date.now()) / 1000);
                nextUpdateElement.textContent = seconds > 0 ? `${seconds}s` : 'Updating...';
            }
        };

        // Update display every second
        setInterval(updateNextUpdateDisplay, 1000);

        // Periodic updates for all stocks
        setInterval(async () => {
            if (!document.hidden) {
                this.updateMarketStatus();
                this.updateStats();
                await this.loadPopularStocks();
            }
        }, this.updateInterval);
    }

    pauseUpdates() {
        // Pause all stock updates when page is hidden
        this.wsConnections.forEach((intervalId) => {
            clearInterval(intervalId);
        });
    }

    resumeUpdates() {
        // Resume updates for all tracked stocks
        this.stocks.forEach((_, symbol) => {
            this.startRealtimeUpdates(symbol);
        });
    }

    // Storage methods
    saveToStorage() {
        try {
            const data = {
                stocks: Array.from(this.stocks.entries()),
                timestamp: Date.now()
            };
            localStorage.setItem('stockTicker', JSON.stringify(data));
        } catch (error) {
            console.error('Error saving to localStorage:', error);
        }
    }

    loadFromStorage() {
        try {
            const saved = localStorage.getItem('stockTicker');
            if (saved) {
                const data = JSON.parse(saved);
                const oneDay = 24 * 60 * 60 * 1000;

                // Load data if it's less than 24 hours old
                if (Date.now() - data.timestamp < oneDay) {
                    this.stocks = new Map(data.stocks);

                    // Recreate UI for loaded stocks
                    this.stocks.forEach((stockData, symbol) => {
                        this.createStockCard(symbol, stockData);
                        this.initializeChart(symbol, stockData);
                        this.startRealtimeUpdates(symbol);
                    });

                    this.updateTickerMarquee();
                    this.updateStats();
                }
            }
        } catch (error) {
            console.error('Error loading from localStorage:', error);
        }
    }

    // Utility methods
    formatNumber(num) {
        if (num >= 1e9) return (num / 1e9).toFixed(1) + 'B';
        if (num >= 1e6) return (num / 1e6).toFixed(1) + 'M';
        if (num >= 1e3) return (num / 1e3).toFixed(1) + 'K';
        return num.toLocaleString();
    }

    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // Message methods
    showMessage(message, type = 'info') {
        const container = document.getElementById('search-message');
        if (!container) return;

        container.innerHTML = `
            <div class="${type}-message" style="animation: fadeIn 0.3s ease;">
                <i class="fas fa-${this.getMessageIcon(type)}"></i>
                ${message}
            </div>
        `;

        // Auto-clear success messages
        if (type === 'success') {
            setTimeout(() => this.clearMessages(), 3000);
        }
    }

    showError(message) {
        this.showMessage(message, 'error');
    }

    showSuccess(message) {
        this.showMessage(message, 'success');
    }

    showLoading(message) {
        const container = document.getElementById('search-message');
        if (!container) return;

        container.innerHTML = `
            <div class="loading">
                <div class="loading-spinner"></div>
                ${message}
            </div>
        `;
    }

    clearMessages() {
        const container = document.getElementById('search-message');
        if (container) {
            container.innerHTML = '';
        }
    }

    getMessageIcon(type) {
        const icons = {
            success: 'check-circle',
            error: 'exclamation-circle',
            info: 'info-circle',
            warning: 'exclamation-triangle'
        };
        return icons[type] || 'info-circle';
    }

    // Performance monitoring
    getPerformanceReport() {
        return {
            ...this.performanceMetrics,
            uptime: Date.now() - this.performanceMetrics.lastUpdate,
            stocksTracked: this.stocks.size,
            chartsActive: this.charts.size,
            wsConnectionsActive: this.wsConnections.size
        };
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.stockTicker = new StockTicker();
});

// Add CSS for animations
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    @keyframes pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.7; }
    }

    .updating {
        animation: pulse 1s infinite;
    }
`;
document.head.appendChild(style);