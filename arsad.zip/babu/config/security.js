/**
 * Security Configuration for Real-Time Stock Ticker
 * Implements security best practices and protection measures
 */

const SecurityConfig = {
  // Content Security Policy
  csp: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: [
        "'self'",
        "'unsafe-inline'", // Required for inline scripts
        "https://cdn.jsdelivr.net",
        "https://cdnjs.cloudflare.com"
      ],
      styleSrc: [
        "'self'",
        "'unsafe-inline'", // Required for inline styles
        "https://fonts.googleapis.com",
        "https://cdnjs.cloudflare.com"
      ],
      fontSrc: [
        "'self'",
        "https://fonts.gstatic.com"
      ],
      imgSrc: [
        "'self'",
        "data:",
        "https:"
      ],
      connectSrc: [
        "'self'",
        "https:",
        "wss:" // WebSocket connections
      ],
      mediaSrc: ["'self'"],
      objectSrc: ["'none'"],
      childSrc: ["'none'"],
      frameAncestors: ["'none'"],
      formAction: ["'self'"],
      upgradeInsecureRequests: []
    }
  },

  // API Security
  api: {
    rateLimit: {
      windowMs: 15 * 60 * 1000, // 15 minutes
      max: 100, // Max requests per window
      message: "Too many requests from this IP"
    },

    cors: {
      origin: process.env.NODE_ENV === 'production' 
        ? ['https://yourdomain.com', 'https://www.yourdomain.com']
        : ['http://localhost:3000', 'http://127.0.0.1:3000'],
      credentials: true,
      optionsSuccessStatus: 200
    },

    // Input validation
    validation: {
      stockSymbol: {
        pattern: /^[A-Z]{1,10}$/,
        maxLength: 10,
        sanitize: true
      }
    }
  },

  // Data Protection
  dataProtection: {
    encryption: {
      algorithm: 'aes-256-gcm',
      keyLength: 32
    },

    // Sensitive data patterns to avoid logging
    sensitiveData: [
      /api[_-]?key/i,
      /password/i,
      /secret/i,
      /token/i
    ],

    // Data retention policy
    retention: {
      stockData: 24 * 60 * 60 * 1000, // 24 hours
      userPreferences: 30 * 24 * 60 * 60 * 1000, // 30 days
      logs: 7 * 24 * 60 * 60 * 1000 // 7 days
    }
  },

  // Security Headers
  headers: {
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains; preload'
  },

  // WebSocket Security
  websocket: {
    origins: process.env.NODE_ENV === 'production'
      ? ['https://yourdomain.com']
      : ['http://localhost:3000'],

    // Connection limits
    maxConnections: 1000,
    connectionTimeout: 30000,

    // Message validation
    messageValidation: {
      maxSize: 1024, // 1KB max message size
      allowedTypes: ['subscribe', 'unsubscribe', 'ping']
    }
  },

  // Error Handling Security
  errorHandling: {
    // Don't expose sensitive information in errors
    sanitizeErrors: true,

    // Generic error messages for production
    genericMessages: {
      validation: 'Invalid input provided',
      authentication: 'Authentication required',
      authorization: 'Access denied',
      rateLimit: 'Too many requests',
      internal: 'An error occurred processing your request'
    }
  }
};

// Security utility functions
const SecurityUtils = {
  // Sanitize input to prevent XSS
  sanitizeInput: (input) => {
    if (typeof input !== 'string') return input;

    return input
      .replace(/[<>"']/g, '')
      .replace(/javascript:/gi, '')
      .replace(/on\w+=/gi, '')
      .trim();
  },

  // Validate stock symbol
  validateStockSymbol: (symbol) => {
    if (!symbol || typeof symbol !== 'string') return false;
    return SecurityConfig.api.validation.stockSymbol.pattern.test(symbol);
  },

  // Generate nonce for CSP
  generateNonce: () => {
    return btoa(String.fromCharCode(...crypto.getRandomValues(new Uint8Array(32))));
  },

  // Check if data contains sensitive information
  containsSensitiveData: (data) => {
    const dataString = JSON.stringify(data).toLowerCase();
    return SecurityConfig.dataProtection.sensitiveData.some(pattern => 
      pattern.test(dataString)
    );
  },

  // Hash sensitive data for logging
  hashSensitiveData: (data) => {
    if (SecurityUtils.containsSensitiveData(data)) {
      return '[SENSITIVE_DATA_REDACTED]';
    }
    return data;
  },

  // Implement rate limiting
  rateLimiter: (() => {
    const requests = new Map();

    return (identifier, limit = 100, windowMs = 15 * 60 * 1000) => {
      const now = Date.now();
      const userRequests = requests.get(identifier) || [];

      // Remove old requests outside the window
      const validRequests = userRequests.filter(time => now - time < windowMs);

      if (validRequests.length >= limit) {
        return false; // Rate limit exceeded
      }

      validRequests.push(now);
      requests.set(identifier, validRequests);

      return true; // Request allowed
    };
  })()
};

// Initialize security measures
const initSecurity = () => {
  // Set up CSP
  const cspString = Object.entries(SecurityConfig.csp.directives)
    .map(([directive, sources]) => 
      `${directive.replace(/([A-Z])/g, '-$1').toLowerCase()} ${sources.join(' ')}`
    )
    .join('; ');

  const metaCsp = document.createElement('meta');
  metaCsp.setAttribute('http-equiv', 'Content-Security-Policy');
  metaCsp.setAttribute('content', cspString);
  document.head.appendChild(metaCsp);

  // Set up error monitoring
  window.addEventListener('error', (event) => {
    console.error('Security Error:', SecurityUtils.hashSensitiveData({
      message: event.message,
      filename: event.filename,
      lineno: event.lineno,
      timestamp: new Date().toISOString()
    }));
  });

  // Monitor for potential XSS attempts
  const originalInnerHTML = Element.prototype.innerHTML;
  Element.prototype.innerHTML = function(value) {
    if (typeof value === 'string' && /<script|javascript:|on\w+=/i.test(value)) {
      console.warn('Potential XSS attempt blocked:', SecurityUtils.hashSensitiveData(value));
      return;
    }
    return originalInnerHTML.call(this, value);
  };

  console.log('Security measures initialized');
};

// Export for use in main application
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { SecurityConfig, SecurityUtils, initSecurity };
} else {
  window.Security = { SecurityConfig, SecurityUtils, initSecurity };
}