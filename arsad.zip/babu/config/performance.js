/**
 * Performance Optimization Configuration
 * Implements performance monitoring and optimization strategies
 */

const PerformanceConfig = {
  // Core Web Vitals targets
  vitals: {
    LCP: 2500, // Largest Contentful Paint (ms)
    FID: 100,  // First Input Delay (ms)
    CLS: 0.1,  // Cumulative Layout Shift
    FCP: 1800, // First Contentful Paint (ms)
    TTI: 3800  // Time to Interactive (ms)
  },

  // Resource optimization
  resources: {
    // Preload critical resources
    preload: [
      { href: '/js/app.js', as: 'script' },
      { href: 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap', as: 'style' },
      { href: 'https://cdn.jsdelivr.net/npm/chart.js', as: 'script' }
    ],

    // Lazy load non-critical resources
    lazyLoad: [
      'charts',
      'analytics',
      'social-widgets'
    ],

    // Resource hints
    prefetch: [
      '/api/market-status',
      '/api/popular-stocks'
    ]
  },

  // API optimization
  api: {
    // Caching strategy
    cache: {
      stockData: { ttl: 30000, strategy: 'stale-while-revalidate' }, // 30 seconds
      marketStatus: { ttl: 300000, strategy: 'cache-first' }, // 5 minutes
      staticData: { ttl: 3600000, strategy: 'cache-first' } // 1 hour
    },

    // Request batching
    batching: {
      enabled: true,
      maxBatchSize: 10,
      batchDelay: 100 // ms
    },

    // Request deduplication
    deduplication: {
      enabled: true,
      window: 1000 // ms
    }
  },

  // Rendering optimization
  rendering: {
    // Virtual scrolling for large lists
    virtualScrolling: {
      enabled: true,
      itemHeight: 200,
      buffer: 5
    },

    // Chart optimization
    charts: {
      maxDataPoints: 50,
      updateThrottle: 16, // 60fps
      animationDuration: 300
    },

    // DOM optimization
    dom: {
      // Batch DOM updates
      batchUpdates: true,

      // Use document fragments for multiple insertions
      useFragments: true,

      // Throttle scroll events
      scrollThrottle: 16
    }
  },

  // Memory management
  memory: {
    // Cleanup intervals
    cleanup: {
      stockHistory: 300000, // 5 minutes
      chartData: 600000,    // 10 minutes
      eventListeners: 60000 // 1 minute
    },

    // Memory limits
    limits: {
      maxStocks: 50,
      maxHistoryPoints: 100,
      maxCacheSize: 10 * 1024 * 1024 // 10MB
    }
  },

  // Network optimization
  network: {
    // Connection strategies
    connection: {
      retry: {
        maxAttempts: 3,
        backoffFactor: 2,
        initialDelay: 1000
      },

      timeout: {
        api: 10000,     // 10 seconds
        websocket: 5000 // 5 seconds
      }
    },

    // Compression
    compression: {
      enabled: true,
      threshold: 1024 // bytes
    }
  }
};

// Performance monitoring utilities
const PerformanceMonitor = {
  // Core Web Vitals measurement
  measureVitals: () => {
    return new Promise((resolve) => {
      const vitals = {};

      // Largest Contentful Paint
      new PerformanceObserver((entryList) => {
        const entries = entryList.getEntries();
        vitals.LCP = entries[entries.length - 1].startTime;
      }).observe({ entryTypes: ['largest-contentful-paint'] });

      // First Input Delay
      new PerformanceObserver((entryList) => {
        vitals.FID = entryList.getEntries()[0].processingStart - entryList.getEntries()[0].startTime;
      }).observe({ entryTypes: ['first-input'] });

      // Cumulative Layout Shift
      new PerformanceObserver((entryList) => {
        vitals.CLS = entryList.getEntries().reduce((sum, entry) => sum + entry.value, 0);
      }).observe({ entryTypes: ['layout-shift'] });

      // Wait for all measurements
      setTimeout(() => resolve(vitals), 5000);
    });
  },

  // Resource timing analysis
  analyzeResources: () => {
    const resources = performance.getEntriesByType('resource');
    const analysis = {
      total: resources.length,
      slow: resources.filter(r => r.duration > 1000),
      large: resources.filter(r => r.transferSize > 100000),
      cached: resources.filter(r => r.transferSize === 0)
    };

    return analysis;
  },

  // Memory usage tracking
  trackMemory: () => {
    if ('memory' in performance) {
      return {
        used: performance.memory.usedJSHeapSize,
        total: performance.memory.totalJSHeapSize,
        limit: performance.memory.jsHeapSizeLimit
      };
    }
    return null;
  },

  // Frame rate monitoring
  monitorFrameRate: (duration = 5000) => {
    return new Promise((resolve) => {
      let frameCount = 0;
      const startTime = performance.now();

      const countFrame = () => {
        frameCount++;
        const elapsed = performance.now() - startTime;

        if (elapsed < duration) {
          requestAnimationFrame(countFrame);
        } else {
          resolve(frameCount / (elapsed / 1000));
        }
      };

      requestAnimationFrame(countFrame);
    });
  }
};

// Performance optimization implementations
const PerformanceOptimizer = {
  // Throttle function calls
  throttle: (func, delay) => {
    let timeoutId;
    let lastExecTime = 0;

    return function (...args) {
      const currentTime = Date.now();

      if (currentTime - lastExecTime > delay) {
        func.apply(this, args);
        lastExecTime = currentTime;
      } else {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => {
          func.apply(this, args);
          lastExecTime = Date.now();
        }, delay - (currentTime - lastExecTime));
      }
    };
  },

  // Debounce function calls
  debounce: (func, delay) => {
    let timeoutId;

    return function (...args) {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => func.apply(this, args), delay);
    };
  },

  // Batch DOM operations
  batchDOM: (operations) => {
    return new Promise((resolve) => {
      requestAnimationFrame(() => {
        const fragment = document.createDocumentFragment();
        operations.forEach(op => op(fragment));
        resolve(fragment);
      });
    });
  },

  // Lazy load resources
  lazyLoad: (selector, callback) => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          callback(entry.target);
          observer.unobserve(entry.target);
        }
      });
    });

    document.querySelectorAll(selector).forEach(el => {
      observer.observe(el);
    });
  },

  // Memory cleanup
  cleanup: () => {
    // Clear expired cache entries
    const now = Date.now();
    Object.keys(localStorage).forEach(key => {
      try {
        const item = JSON.parse(localStorage.getItem(key));
        if (item.expires && item.expires < now) {
          localStorage.removeItem(key);
        }
      } catch (e) {
        // Invalid JSON, remove it
        localStorage.removeItem(key);
      }
    });

    // Force garbage collection if available
    if (window.gc) {
      window.gc();
    }
  },

  // Preload critical resources
  preloadResources: () => {
    PerformanceConfig.resources.preload.forEach(resource => {
      const link = document.createElement('link');
      link.rel = 'preload';
      link.href = resource.href;
      link.as = resource.as;
      if (resource.type) link.type = resource.type;
      document.head.appendChild(link);
    });
  }
};

// Performance monitoring initialization
const initPerformance = () => {
  // Set up performance monitoring
  PerformanceMonitor.measureVitals().then(vitals => {
    console.log('Core Web Vitals:', vitals);

    // Check if vitals meet targets
    Object.entries(vitals).forEach(([metric, value]) => {
      const target = PerformanceConfig.vitals[metric];
      if (target && value > target) {
        console.warn(`Performance Warning: ${metric} (${value}) exceeds target (${target})`);
      }
    });
  });

  // Preload critical resources
  PerformanceOptimizer.preloadResources();

  // Set up periodic cleanup
  setInterval(PerformanceOptimizer.cleanup, PerformanceConfig.memory.cleanup.stockHistory);

  // Monitor frame rate
  PerformanceMonitor.monitorFrameRate().then(fps => {
    console.log('Average FPS:', fps);
    if (fps < 55) {
      console.warn('Low frame rate detected. Consider optimizing animations.');
    }
  });

  console.log('Performance monitoring initialized');
};

// Export for use in main application
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { PerformanceConfig, PerformanceMonitor, PerformanceOptimizer, initPerformance };
} else {
  window.Performance = { PerformanceConfig, PerformanceMonitor, PerformanceOptimizer, initPerformance };
}