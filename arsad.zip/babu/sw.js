/**
 * Service Worker for Real-Time Stock Ticker
 * Provides offline functionality and caching strategies
 */

const CACHE_NAME = 'stock-ticker-v1.2.0';
const RUNTIME_CACHE = 'runtime-cache-v1.2.0';

// Files to cache on install
const STATIC_ASSETS = [
    '/',
    '/index.html',
    '/js/app.js',
    '/manifest.json',
    'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css',
    'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap',
    'https://cdn.jsdelivr.net/npm/chart.js'
];

// API endpoints that should be cached
const API_CACHE_PATTERNS = [
    /^https:\/\/api\..*stock.*/i,
    /^https:\/\/.*\.finance\.yahoo\.com.*/i,
    /^https:\/\/.*\.alphavantage\.co.*/i
];

// Install event - cache static assets
self.addEventListener('install', event => {
    console.log('Service Worker installing...');

    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('Caching static assets');
                return cache.addAll(STATIC_ASSETS);
            })
            .catch(error => {
                console.error('Cache installation failed:', error);
            })
    );

    // Skip waiting to activate immediately
    self.skipWaiting();
});

// Activate event - clean up old caches
self.addEventListener('activate', event => {
    console.log('Service Worker activating...');

    event.waitUntil(
        caches.keys()
            .then(cacheNames => {
                return Promise.all(
                    cacheNames.map(cacheName => {
                        // Delete old caches
                        if (cacheName !== CACHE_NAME && cacheName !== RUNTIME_CACHE) {
                            console.log('Deleting old cache:', cacheName);
                            return caches.delete(cacheName);
                        }
                    })
                );
            })
            .then(() => {
                // Claim all clients
                return self.clients.claim();
            })
    );
});

// Fetch event - implement caching strategies
self.addEventListener('fetch', event => {
    const { request } = event;
    const url = new URL(request.url);

    // Skip non-HTTP requests
    if (!request.url.startsWith('http')) {
        return;
    }

    // Handle different types of requests
    if (request.destination === 'document') {
        // HTML documents - Network First strategy
        event.respondWith(networkFirst(request));
    } else if (isStaticAsset(request)) {
        // Static assets - Cache First strategy
        event.respondWith(cacheFirst(request));
    } else if (isAPIRequest(request)) {
        // API requests - Network First with short cache
        event.respondWith(networkFirstAPI(request));
    } else {
        // Everything else - Network First
        event.respondWith(networkFirst(request));
    }
});

// Cache First strategy for static assets
async function cacheFirst(request) {
    try {
        const cachedResponse = await caches.match(request);
        if (cachedResponse) {
            return cachedResponse;
        }

        const networkResponse = await fetch(request);
        if (networkResponse.ok) {
            const cache = await caches.open(CACHE_NAME);
            cache.put(request, networkResponse.clone());
        }

        return networkResponse;
    } catch (error) {
        console.error('Cache first strategy failed:', error);
        return new Response('Offline content not available', { status: 503 });
    }
}

// Network First strategy for HTML documents
async function networkFirst(request) {
    try {
        const networkResponse = await fetch(request);

        if (networkResponse.ok) {
            const cache = await caches.open(RUNTIME_CACHE);
            cache.put(request, networkResponse.clone());
        }

        return networkResponse;
    } catch (error) {
        console.log('Network failed, trying cache:', error);

        const cachedResponse = await caches.match(request);
        if (cachedResponse) {
            return cachedResponse;
        }

        // Return offline page or basic response
        if (request.destination === 'document') {
            return caches.match('/') || new Response('Offline', { status: 503 });
        }

        return new Response('Resource not available offline', { status: 503 });
    }
}

// Network First strategy for API requests with shorter cache time
async function networkFirstAPI(request) {
    try {
        const networkResponse = await fetch(request);

        if (networkResponse.ok) {
            // Cache API responses for 5 minutes
            const responseToCache = networkResponse.clone();
            const cache = await caches.open(RUNTIME_CACHE);

            // Add timestamp to track cache age
            const headers = new Headers(responseToCache.headers);
            headers.set('sw-cache-timestamp', Date.now().toString());

            const cachedResponse = new Response(responseToCache.body, {
                status: responseToCache.status,
                statusText: responseToCache.statusText,
                headers: headers
            });

            cache.put(request, cachedResponse);
        }

        return networkResponse;
    } catch (error) {
        console.log('API network failed, trying cache:', error);

        const cachedResponse = await caches.match(request);
        if (cachedResponse) {
            // Check if cached response is still fresh (5 minutes)
            const cacheTimestamp = cachedResponse.headers.get('sw-cache-timestamp');
            const cacheAge = Date.now() - parseInt(cacheTimestamp || '0');
            const maxAge = 5 * 60 * 1000; // 5 minutes

            if (cacheAge < maxAge) {
                return cachedResponse;
            } else {
                // Cache is stale, delete it
                const cache = await caches.open(RUNTIME_CACHE);
                cache.delete(request);
            }
        }

        // Return mock data for offline functionality
        return getMockResponse(request);
    }
}

// Check if request is for a static asset
function isStaticAsset(request) {
    const url = new URL(request.url);
    return request.destination === 'style' ||
           request.destination === 'script' ||
           request.destination === 'font' ||
           request.destination === 'image' ||
           url.pathname.endsWith('.css') ||
           url.pathname.endsWith('.js') ||
           url.pathname.endsWith('.png') ||
           url.pathname.endsWith('.jpg') ||
           url.pathname.endsWith('.jpeg') ||
           url.pathname.endsWith('.svg') ||
           url.pathname.endsWith('.woff') ||
           url.pathname.endsWith('.woff2');
}

// Check if request is for an API
function isAPIRequest(request) {
    const url = new URL(request.url);
    return API_CACHE_PATTERNS.some(pattern => pattern.test(request.url)) ||
           url.pathname.startsWith('/api/');
}

// Generate mock response for offline API requests
function getMockResponse(request) {
    const url = new URL(request.url);

    // Mock stock data for offline mode
    if (url.pathname.includes('stock') || url.pathname.includes('quote')) {
        const mockData = {
            symbol: 'OFFLINE',
            name: 'Offline Mode',
            price: 100.00,
            change: 0.00,
            changePercent: 0.00,
            volume: 0,
            timestamp: Date.now(),
            offline: true
        };

        return new Response(JSON.stringify(mockData), {
            status: 200,
            headers: {
                'Content-Type': 'application/json',
                'X-Offline-Response': 'true'
            }
        });
    }

    return new Response('Service temporarily unavailable', { 
        status: 503,
        headers: {
            'Content-Type': 'text/plain'
        }
    });
}

// Handle background sync for data updates
self.addEventListener('sync', event => {
    console.log('Background sync triggered:', event.tag);

    if (event.tag === 'stock-data-sync') {
        event.waitUntil(syncStockData());
    }
});

// Sync stock data in the background
async function syncStockData() {
    try {
        // Get stored stock symbols from cache
        const cache = await caches.open(RUNTIME_CACHE);
        const stockRequests = await cache.keys();

        // Update cached data for each stock
        for (const request of stockRequests) {
            if (isAPIRequest(request)) {
                try {
                    const response = await fetch(request);
                    if (response.ok) {
                        cache.put(request, response.clone());
                    }
                } catch (error) {
                    console.log('Failed to sync:', request.url);
                }
            }
        }

        console.log('Stock data sync completed');
    } catch (error) {
        console.error('Stock data sync failed:', error);
    }
}

// Handle push notifications (future enhancement)
self.addEventListener('push', event => {
    if (!event.data) return;

    try {
        const data = event.data.json();
        const options = {
            body: data.body || 'Stock price alert',
            icon: '/icons/icon-192x192.png',
            badge: '/icons/icon-72x72.png',
            vibrate: [300, 200, 300],
            data: data.data || {},
            actions: [
                {
                    action: 'view',
                    title: 'View Stock',
                    icon: '/icons/view-icon.png'
                },
                {
                    action: 'dismiss',
                    title: 'Dismiss',
                    icon: '/icons/dismiss-icon.png'
                }
            ]
        };

        event.waitUntil(
            self.registration.showNotification(data.title || 'Stock Alert', options)
        );
    } catch (error) {
        console.error('Push notification error:', error);
    }
});

// Handle notification clicks
self.addEventListener('notificationclick', event => {
    event.notification.close();

    if (event.action === 'view') {
        // Open the app to view the stock
        event.waitUntil(
            clients.openWindow('/?stock=' + encodeURIComponent(event.notification.data.symbol || ''))
        );
    } else if (event.action === 'dismiss') {
        // Just close the notification
        return;
    } else {
        // Default action - open the app
        event.waitUntil(
            clients.openWindow('/')
        );
    }
});

// Message handling for communication with main app
self.addEventListener('message', event => {
    console.log('Service Worker received message:', event.data);

    if (event.data && event.data.type) {
        switch (event.data.type) {
            case 'SKIP_WAITING':
                self.skipWaiting();
                break;
            case 'GET_VERSION':
                event.ports[0].postMessage({ version: CACHE_NAME });
                break;
            case 'CLEAR_CACHE':
                clearAllCaches().then(() => {
                    event.ports[0].postMessage({ success: true });
                }).catch(error => {
                    event.ports[0].postMessage({ success: false, error: error.message });
                });
                break;
        }
    }
});

// Clear all caches
async function clearAllCaches() {
    const cacheNames = await caches.keys();
    return Promise.all(cacheNames.map(name => caches.delete(name)));
}