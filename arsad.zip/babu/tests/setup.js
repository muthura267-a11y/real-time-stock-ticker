/**
 * Jest Test Setup
 * Global test configuration and utilities
 */

import '@testing-library/jest-dom';

// Mock Chart.js
global.Chart = class MockChart {
    constructor(ctx, config) {
        this.ctx = ctx;
        this.config = config;
        this.data = config.data;
    }

    update() {}
    destroy() {}

    static register() {}
};

// Mock WebSocket
global.WebSocket = class MockWebSocket {
    constructor(url) {
        this.url = url;
        this.readyState = WebSocket.CONNECTING;
        setTimeout(() => {
            this.readyState = WebSocket.OPEN;
            if (this.onopen) this.onopen();
        }, 100);
    }

    send(data) {
        // Mock send
    }

    close() {
        this.readyState = WebSocket.CLOSED;
        if (this.onclose) this.onclose();
    }

    static get CONNECTING() { return 0; }
    static get OPEN() { return 1; }
    static get CLOSING() { return 2; }
    static get CLOSED() { return 3; }
};

// Mock fetch
global.fetch = jest.fn(() =>
    Promise.resolve({
        ok: true,
        json: () => Promise.resolve({
            symbol: 'TEST',
            name: 'Test Stock',
            price: 100.00,
            change: 2.50,
            changePercent: 2.56,
            volume: 1000000
        }),
    })
);

// Mock localStorage
const localStorageMock = {
    getItem: jest.fn(),
    setItem: jest.fn(),
    removeItem: jest.fn(),
    clear: jest.fn(),
};
global.localStorage = localStorageMock;

// Mock performance API
global.performance = {
    now: jest.fn(() => Date.now()),
    mark: jest.fn(),
    measure: jest.fn(),
};

// Mock console methods for cleaner test output
global.console = {
    ...console,
    log: jest.fn(),
    warn: jest.fn(),
    error: jest.fn(),
};

// Test utilities
global.testUtils = {
    // Wait for async operations
    waitFor: (condition, timeout = 5000) => {
        return new Promise((resolve, reject) => {
            const startTime = Date.now();
            const check = () => {
                if (condition()) {
                    resolve();
                } else if (Date.now() - startTime > timeout) {
                    reject(new Error('Timeout waiting for condition'));
                } else {
                    setTimeout(check, 100);
                }
            };
            check();
        });
    },

    // Create mock stock data
    createMockStock: (symbol = 'TEST', price = 100) => ({
        symbol,
        name: `${symbol} Corp`,
        price,
        change: (Math.random() - 0.5) * 10,
        changePercent: (Math.random() - 0.5) * 5,
        volume: Math.floor(Math.random() * 10000000),
        timestamp: Date.now()
    }),

    // Setup DOM
    setupDOM: () => {
        document.body.innerHTML = `
            <div id="stock-grid"></div>
            <div id="search-message"></div>
            <form id="stock-search-form">
                <input id="stock-symbol-input" type="text">
                <button type="submit">Add</button>
            </form>
            <div id="ticker-content"></div>
            <div id="active-stocks">0</div>
            <div id="last-update">--:--</div>
        `;
    },

    // Clean up DOM
    cleanupDOM: () => {
        document.body.innerHTML = '';
    }
};

// Setup DOM before each test
beforeEach(() => {
    global.testUtils.setupDOM();
    jest.clearAllMocks();
});

// Cleanup after each test
afterEach(() => {
    global.testUtils.cleanupDOM();
});