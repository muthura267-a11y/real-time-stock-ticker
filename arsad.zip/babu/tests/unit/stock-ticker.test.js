/**
 * Unit Tests for StockTicker Application
 * Tests core functionality, data handling, and UI interactions
 */

describe('StockTicker', () => {
    let stockTicker;

    beforeEach(() => {
        // Mock the Chart.js dependency
        global.Chart = jest.fn().mockImplementation(() => ({
            update: jest.fn(),
            destroy: jest.fn()
        }));

        // Import and initialize StockTicker
        const StockTickerClass = require('../../js/app.js').StockTicker;
        stockTicker = new StockTickerClass();
    });

    describe('Initialization', () => {
        test('should initialize with empty stocks map', () => {
            expect(stockTicker.stocks).toBeInstanceOf(Map);
            expect(stockTicker.stocks.size).toBe(0);
        });

        test('should set default configuration values', () => {
            expect(stockTicker.updateInterval).toBe(30000);
            expect(stockTicker.maxRetries).toBe(3);
            expect(stockTicker.retryDelay).toBe(2000);
        });

        test('should initialize performance metrics', () => {
            expect(stockTicker.performanceMetrics).toEqual({
                apiCalls: 0,
                wsConnections: 0,
                errors: 0,
                lastUpdate: expect.any(Number)
            });
        });
    });

    describe('Stock Management', () => {
        test('should add stock successfully', async () => {
            const mockData = global.testUtils.createMockStock('AAPL', 150.00);
            jest.spyOn(stockTicker, 'fetchStockData').mockResolvedValue(mockData);
            jest.spyOn(stockTicker, 'createStockCard').mockImplementation(() => {});
            jest.spyOn(stockTicker, 'initializeChart').mockImplementation(() => {});

            await stockTicker.addStock('AAPL');

            expect(stockTicker.stocks.has('AAPL')).toBe(true);
            expect(stockTicker.stocks.get('AAPL')).toMatchObject(mockData);
        });

        test('should prevent adding duplicate stocks', async () => {
            const mockData = global.testUtils.createMockStock('AAPL');
            stockTicker.stocks.set('AAPL', mockData);
            jest.spyOn(stockTicker, 'showError');

            await stockTicker.addStock('AAPL');

            expect(stockTicker.showError).toHaveBeenCalledWith('AAPL is already being tracked');
        });

        test('should remove stock successfully', async () => {
            const mockData = global.testUtils.createMockStock('AAPL');
            stockTicker.stocks.set('AAPL', mockData);
            stockTicker.charts.set('AAPL', { destroy: jest.fn() });

            // Mock confirmation dialog
            global.confirm = jest.fn(() => true);

            // Mock DOM element
            const mockCard = document.createElement('div');
            mockCard.id = 'stock-AAPL';
            document.body.appendChild(mockCard);
            jest.spyOn(stockTicker, 'stopRealtimeUpdates').mockImplementation(() => {});

            await stockTicker.removeStock('AAPL');

            expect(stockTicker.stocks.has('AAPL')).toBe(false);
        });

        test('should handle API errors gracefully', async () => {
            jest.spyOn(stockTicker, 'fetchStockData').mockRejectedValue(new Error('API Error'));
            jest.spyOn(stockTicker, 'showError');

            await stockTicker.addStock('INVALID');

            expect(stockTicker.showError).toHaveBeenCalled();
            expect(stockTicker.stocks.has('INVALID')).toBe(false);
        });
    });

    describe('Data Fetching', () => {
        test('should fetch mock stock data', async () => {
            const data = await stockTicker.getMockStockData('AAPL');

            expect(data).toMatchObject({
                symbol: 'AAPL',
                name: 'Apple Inc.',
                price: expect.any(Number),
                change: expect.any(Number),
                changePercent: expect.any(Number)
            });
        });

        test('should return null for unknown stock', async () => {
            const data = await stockTicker.getMockStockData('UNKNOWN');
            expect(data).toBeNull();
        });

        test('should increment API call counter', async () => {
            const initialCalls = stockTicker.performanceMetrics.apiCalls;
            await stockTicker.fetchStockData('AAPL');
            expect(stockTicker.performanceMetrics.apiCalls).toBe(initialCalls + 1);
        });
    });

    describe('UI Updates', () => {
        test('should update ticker marquee', () => {
            const mockStocks = new Map([
                ['AAPL', { symbol: 'AAPL', price: 150, change: 2.5, changePercent: 1.7 }],
                ['GOOGL', { symbol: 'GOOGL', price: 2500, change: -10, changePercent: -0.4 }]
            ]);
            stockTicker.stocks = mockStocks;

            const tickerContent = document.createElement('div');
            tickerContent.id = 'ticker-content';
            document.body.appendChild(tickerContent);

            stockTicker.updateTickerMarquee();

            expect(tickerContent.innerHTML).toContain('AAPL');
            expect(tickerContent.innerHTML).toContain('GOOGL');
            expect(tickerContent.innerHTML).toContain('$150.00');
            expect(tickerContent.innerHTML).toContain('positive');
            expect(tickerContent.innerHTML).toContain('negative');
        });

        test('should update statistics', () => {
            stockTicker.stocks.set('AAPL', {});
            stockTicker.stocks.set('GOOGL', {});

            const activeStocksElement = document.createElement('span');
            activeStocksElement.id = 'active-stocks';
            document.body.appendChild(activeStocksElement);

            stockTicker.updateStats();

            expect(activeStocksElement.textContent).toBe('2');
        });
    });

    describe('Message System', () => {
        test('should show error message', () => {
            const container = document.createElement('div');
            container.id = 'search-message';
            document.body.appendChild(container);

            stockTicker.showError('Test error');

            expect(container.innerHTML).toContain('error-message');
            expect(container.innerHTML).toContain('Test error');
        });

        test('should show success message', () => {
            const container = document.createElement('div');
            container.id = 'search-message';
            document.body.appendChild(container);

            stockTicker.showSuccess('Test success');

            expect(container.innerHTML).toContain('success-message');
            expect(container.innerHTML).toContain('Test success');
        });

        test('should clear messages', () => {
            const container = document.createElement('div');
            container.id = 'search-message';
            container.innerHTML = '<div>Some message</div>';
            document.body.appendChild(container);

            stockTicker.clearMessages();

            expect(container.innerHTML).toBe('');
        });
    });

    describe('Storage Operations', () => {
        test('should save to localStorage', () => {
            stockTicker.stocks.set('AAPL', { symbol: 'AAPL', price: 150 });

            stockTicker.saveToStorage();

            expect(localStorage.setItem).toHaveBeenCalledWith(
                'stockTicker',
                expect.stringContaining('AAPL')
            );
        });

        test('should load from localStorage', () => {
            const mockData = {
                stocks: [['AAPL', { symbol: 'AAPL', price: 150 }]],
                timestamp: Date.now()
            };
            localStorage.getItem.mockReturnValue(JSON.stringify(mockData));
            jest.spyOn(stockTicker, 'createStockCard').mockImplementation(() => {});
            jest.spyOn(stockTicker, 'initializeChart').mockImplementation(() => {});

            stockTicker.loadFromStorage();

            expect(stockTicker.stocks.has('AAPL')).toBe(true);
        });
    });

    describe('Utility Functions', () => {
        test('should format numbers correctly', () => {
            expect(stockTicker.formatNumber(1000)).toBe('1.0K');
            expect(stockTicker.formatNumber(1000000)).toBe('1.0M');
            expect(stockTicker.formatNumber(1000000000)).toBe('1.0B');
            expect(stockTicker.formatNumber(500)).toBe('500');
        });

        test('should generate unique IDs', () => {
            const id1 = stockTicker.generateId();
            const id2 = stockTicker.generateId();

            expect(id1).not.toBe(id2);
            expect(typeof id1).toBe('string');
            expect(id1.length).toBeGreaterThan(0);
        });

        test('should handle delay function', async () => {
            const start = Date.now();
            await stockTicker.delay(100);
            const end = Date.now();

            expect(end - start).toBeGreaterThanOrEqual(90);
        });
    });

    describe('Performance Monitoring', () => {
        test('should generate performance report', () => {
            const report = stockTicker.getPerformanceReport();

            expect(report).toMatchObject({
                apiCalls: expect.any(Number),
                wsConnections: expect.any(Number),
                errors: expect.any(Number),
                uptime: expect.any(Number),
                stocksTracked: expect.any(Number),
                chartsActive: expect.any(Number)
            });
        });
    });
});