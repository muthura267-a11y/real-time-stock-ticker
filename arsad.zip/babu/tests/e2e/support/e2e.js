/**
 * Cypress E2E Support File
 * Custom commands and global configurations
 */

import 'cypress-axe';

// Custom command for adding stocks
Cypress.Commands.add('addStock', (symbol) => {
  cy.get('#stock-symbol-input').clear().type(symbol);
  cy.get('#stock-search-form').submit();
  cy.get(`[data-symbol="${symbol}"]`, { timeout: 10000 }).should('exist');
});

// Custom command for removing stocks
Cypress.Commands.add('removeStock', (symbol) => {
  cy.get(`#stock-${symbol} .remove-btn`).click();
  cy.on('window:confirm', () => true);
  cy.get(`#stock-${symbol}`).should('not.exist');
});

// Custom command for checking stock data
Cypress.Commands.add('verifyStockData', (symbol) => {
  cy.get(`#stock-${symbol}`).within(() => {
    cy.get('.stock-symbol').should('contain', symbol);
    cy.get('.stock-price').should('match', /\$\d+\.\d{2}/);
    cy.get('.stock-change').should('exist');
  });
});

// Custom command for waiting for market data to load
Cypress.Commands.add('waitForMarketData', () => {
  cy.get('#ticker-content .loading').should('not.exist');
  cy.get('.ticker-item').should('have.length.greaterThan', 0);
});

// Custom command for mobile testing
Cypress.Commands.add('testMobileLayout', () => {
  cy.viewport(375, 667);
  cy.get('.main-container').should('have.css', 'grid-template-columns', '1fr');
  cy.get('.header-content').should('have.css', 'flex-direction', 'column');
});

// Custom command for accessibility testing
Cypress.Commands.add('checkA11y', (context = null, options = null) => {
  cy.injectAxe();
  cy.checkA11y(context, options);
});

// Custom command for performance testing
Cypress.Commands.add('measurePerformance', () => {
  cy.window().then((win) => {
    const performance = win.performance;
    const navigation = performance.getEntriesByType('navigation')[0];

    expect(navigation.loadEventEnd - navigation.navigationStart).to.be.lessThan(3000);
    expect(navigation.domContentLoadedEventEnd - navigation.navigationStart).to.be.lessThan(2000);
  });
});

// Global error handling
Cypress.on('uncaught:exception', (err, runnable) => {
  // Prevent Cypress from failing the test on unhandled errors
  // that might come from third-party libraries
  if (err.message.includes('ResizeObserver')) {
    return false;
  }
  if (err.message.includes('Script error')) {
    return false;
  }
  return true;
});

// Before each test
beforeEach(() => {
  // Mock API responses for consistent testing
  cy.intercept('GET', '**/stock-data/**', { fixture: 'stock-data.json' }).as('getStockData');
  cy.intercept('GET', '**/market-status/**', { fixture: 'market-status.json' }).as('getMarketStatus');

  // Visit the application
  cy.visit('/');

  // Wait for initial load
  cy.get('body').should('be.visible');
  cy.get('.header').should('be.visible');
});