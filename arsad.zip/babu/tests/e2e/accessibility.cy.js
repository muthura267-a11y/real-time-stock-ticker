/**
 * Accessibility E2E Tests
 * Tests WCAG compliance and screen reader compatibility
 */

describe('Accessibility Tests', () => {

  it('should pass basic accessibility audit', () => {
    cy.visit('/');
    cy.checkA11y();
  });

  it('should have proper heading hierarchy', () => {
    cy.visit('/');

    // Check for proper heading structure
    cy.get('h1, h2, h3, h4, h5, h6').each(($heading, index) => {
      cy.wrap($heading).should('be.visible');
    });
  });

  it('should have proper form labels', () => {
    cy.visit('/');

    // Check form accessibility
    cy.get('#stock-symbol-input').should('have.attr', 'aria-label');
    cy.get('button[type="submit"]').should('have.attr', 'aria-label');
  });

  it('should have proper color contrast', () => {
    cy.visit('/');

    // Check color contrast (this would be handled by axe-core)
    cy.checkA11y(null, {
      rules: {
        'color-contrast': { enabled: true }
      }
    });
  });

  it('should be keyboard navigable', () => {
    cy.visit('/');

    // Tab through interactive elements
    cy.get('body').tab();
    cy.focused().should('have.id', 'stock-symbol-input');

    cy.focused().tab();
    cy.focused().should('contain', 'Add Stock');
  });

  it('should have proper ARIA attributes', () => {
    cy.visit('/');

    // Add a stock to test dynamic content
    cy.addStock('AAPL');

    // Check ARIA attributes on stock cards
    cy.get('#stock-AAPL').should('have.attr', 'role').and('equal', 'article');
    cy.get('#chart-AAPL').should('have.attr', 'aria-label');
  });

  it('should announce dynamic content changes', () => {
    cy.visit('/');

    // Check for live regions
    cy.get('[aria-live]').should('exist');

    // Add stock and verify announcement
    cy.addStock('GOOGL');
    cy.get('#search-message').should('have.attr', 'aria-live');
  });

  it('should work with high contrast mode', () => {
    cy.visit('/');

    // Simulate high contrast mode
    cy.get('html').invoke('attr', 'style', 'filter: contrast(200%)');

    // Check that content is still readable
    cy.get('.header').should('be.visible');
    cy.get('.stock-grid').should('be.visible');
  });

  it('should support screen reader users', () => {
    cy.visit('/');

    // Check for screen reader specific content
    cy.get('.sr-only, [aria-hidden="false"]').should('exist');

    // Check skip links (if implemented)
    cy.get('a[href="#main-content"]').should('exist');
  });
});