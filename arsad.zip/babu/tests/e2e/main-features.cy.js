/**
 * Main E2E Tests for Stock Ticker Application
 * Tests complete user workflows and interactions
 */

describe('Stock Ticker Application - Main Features', () => {

  it('should load the application successfully', () => {
    cy.visit('/');

    // Check if main elements are present
    cy.get('.header').should('be.visible');
    cy.get('.ticker-marquee').should('be.visible');
    cy.get('.main-container').should('be.visible');
    cy.get('#stock-search-form').should('be.visible');

    // Check initial state
    cy.get('#active-stocks').should('contain', '0');
    cy.get('#stock-grid .loading').should('be.visible');

    // Measure performance
    cy.measurePerformance();
  });

  it('should add a stock successfully', () => {
    // Add AAPL stock
    cy.addStock('AAPL');

    // Verify stock was added
    cy.verifyStockData('AAPL');
    cy.get('#active-stocks').should('contain', '1');

    // Verify chart is present
    cy.get('#chart-AAPL').should('be.visible');

    // Verify ticker marquee is updated
    cy.get('.ticker-item').should('contain', 'AAPL');
  });

  it('should handle multiple stocks', () => {
    const stocks = ['AAPL', 'GOOGL', 'TSLA'];

    // Add multiple stocks
    stocks.forEach(stock => {
      cy.addStock(stock);
    });

    // Verify all stocks are present
    stocks.forEach(stock => {
      cy.verifyStockData(stock);
    });

    cy.get('#active-stocks').should('contain', stocks.length.toString());

    // Verify ticker shows all stocks
    stocks.forEach(stock => {
      cy.get('.ticker-content').should('contain', stock);
    });
  });

  it('should remove a stock', () => {
    // Add stock first
    cy.addStock('MSFT');
    cy.verifyStockData('MSFT');

    // Remove the stock
    cy.removeStock('MSFT');

    // Verify stock is removed
    cy.get('#stock-MSFT').should('not.exist');
    cy.get('#active-stocks').should('contain', '0');
  });

  it('should prevent adding duplicate stocks', () => {
    // Add stock
    cy.addStock('AMZN');
    cy.verifyStockData('AMZN');

    // Try to add same stock again
    cy.get('#stock-symbol-input').clear().type('AMZN');
    cy.get('#stock-search-form').submit();

    // Should show error message
    cy.get('#search-message').should('contain', 'already being tracked');

    // Should still have only one stock
    cy.get('#active-stocks').should('contain', '1');
  });

  it('should handle invalid stock symbols', () => {
    // Try to add invalid stock
    cy.get('#stock-symbol-input').clear().type('INVALIDSTOCK');
    cy.get('#stock-search-form').submit();

    // Should show error message
    cy.get('#search-message .error-message').should('be.visible');

    // Should not add the stock
    cy.get('#stock-INVALIDSTOCK').should('not.exist');
    cy.get('#active-stocks').should('contain', '0');
  });

  it('should update stock prices in real-time', () => {
    cy.addStock('NVDA');

    // Get initial price
    cy.get('#stock-NVDA .stock-price').invoke('text').then((initialPrice) => {
      // Wait for price update (mocked)
      cy.wait(5000);

      // Price might change (in real implementation)
      cy.get('#stock-NVDA .stock-price').should('be.visible');
      cy.get('#stock-NVDA .stock-change').should('be.visible');
    });
  });

  it('should persist data in localStorage', () => {
    // Add some stocks
    cy.addStock('META');
    cy.addStock('NFLX');

    // Reload page
    cy.reload();

    // Verify stocks are still there
    cy.verifyStockData('META');
    cy.verifyStockData('NFLX');
    cy.get('#active-stocks').should('contain', '2');
  });

  it('should be responsive on mobile devices', () => {
    // Test mobile layout
    cy.testMobileLayout();

    // Add stock on mobile
    cy.addStock('AMD');
    cy.verifyStockData('AMD');

    // Verify mobile-specific elements
    cy.get('.search-form').should('have.css', 'flex-direction', 'column');
    cy.get('.stock-grid').should('have.css', 'grid-template-columns', '1fr');
  });

  it('should handle keyboard interactions', () => {
    // Focus on input
    cy.get('#stock-symbol-input').focus();

    // Type stock symbol
    cy.get('#stock-symbol-input').type('CRM');

    // Submit with Enter key
    cy.get('#stock-symbol-input').type('{enter}');

    // Verify stock was added
    cy.verifyStockData('CRM');

    // Test Escape key to clear input
    cy.get('#stock-symbol-input').type('TEST{esc}');
    cy.get('#stock-symbol-input').should('have.value', '');
  });

  it('should update market status', () => {
    // Check initial market status
    cy.get('#market-status').should('not.contain', 'Loading...');
    cy.get('#nyse-status').should('be.visible');
    cy.get('#nasdaq-status').should('be.visible');

    // Market status should be either Open or Closed
    cy.get('#market-status').should('match', /(Open|Closed)/);
  });

  it('should show proper error states', () => {
    // Mock network error
    cy.intercept('GET', '**/stock-data/**', { statusCode: 500 }).as('getStockDataError');

    // Try to add stock
    cy.get('#stock-symbol-input').clear().type('ERRORTEST');
    cy.get('#stock-search-form').submit();

    // Should show error
    cy.get('#search-message .error-message').should('be.visible');
  });

  it('should handle offline functionality', () => {
    // Add stock while online
    cy.addStock('AAPL');

    // Simulate offline
    cy.window().then((win) => {
      win.dispatchEvent(new Event('offline'));
    });

    // Should show offline message
    cy.get('.error-message').should('contain', 'Connection lost');

    // Simulate back online
    cy.window().then((win) => {
      win.dispatchEvent(new Event('online'));
    });

    // Should show restored message
    cy.get('.success-message').should('contain', 'Connection restored');
  });
});