/**
 * Performance E2E Tests
 * Tests application performance metrics and optimization
 */

describe('Performance Tests', () => {

  it('should load within acceptable time limits', () => {
    cy.visit('/', {
      onBeforeLoad: (win) => {
        win.performance.mark('start');
      },
      onLoad: (win) => {
        win.performance.mark('end');
        win.performance.measure('pageLoad', 'start', 'end');

        const measure = win.performance.getEntriesByName('pageLoad')[0];
        expect(measure.duration).to.be.lessThan(3000); // 3 seconds
      }
    });
  });

  it('should handle multiple stocks without performance degradation', () => {
    const stocks = ['AAPL', 'GOOGL', 'TSLA', 'MSFT', 'AMZN', 'NVDA', 'META', 'NFLX', 'AMD', 'CRM'];

    // Measure time to add all stocks
    const startTime = Date.now();

    stocks.forEach(stock => {
      cy.addStock(stock);
    });

    cy.then(() => {
      const endTime = Date.now();
      const totalTime = endTime - startTime;

      // Should add all stocks within reasonable time
      expect(totalTime).to.be.lessThan(30000); // 30 seconds
    });

    // Check that all charts are rendered
    stocks.forEach(stock => {
      cy.get(`#chart-${stock}`).should('be.visible');
    });
  });

  it('should optimize chart updates', () => {
    cy.addStock('AAPL');

    // Monitor chart update performance
    cy.window().then((win) => {
      const observer = new win.PerformanceObserver((list) => {
        const entries = list.getEntries();
        entries.forEach((entry) => {
          if (entry.name.includes('chart-update')) {
            expect(entry.duration).to.be.lessThan(16); // 60fps = 16.67ms
          }
        });
      });
      observer.observe({ entryTypes: ['measure'] });
    });

    // Trigger multiple updates
    for (let i = 0; i < 10; i++) {
      cy.wait(1000);
      cy.get('#stock-AAPL').should('be.visible');
    }
  });

  it('should handle memory efficiently', () => {
    // Add and remove stocks to test memory leaks
    const testStocks = ['AAPL', 'GOOGL', 'TSLA'];

    testStocks.forEach(stock => {
      cy.addStock(stock);
      cy.wait(2000);
      cy.removeStock(stock);
      cy.wait(2000);
    });

    // Check memory usage (simplified check)
    cy.window().then((win) => {
      if (win.performance.memory) {
        const memoryInfo = win.performance.memory;
        expect(memoryInfo.usedJSHeapSize).to.be.lessThan(50000000); // 50MB
      }
    });
  });

  it('should lazy load resources', () => {
    cy.visit('/');

    // Check that only essential resources are loaded initially
    cy.window().then((win) => {
      const resources = win.performance.getEntriesByType('resource');
      const criticalResources = resources.filter(r => 
        r.name.includes('app.js') || 
        r.name.includes('style') || 
        r.name.includes('font')
      );

      expect(criticalResources.length).to.be.greaterThan(0);
    });
  });

  it('should cache resources effectively', () => {
    cy.visit('/');

    // First visit
    cy.window().then((win) => {
      win.performance.mark('first-visit');
    });

    // Reload page
    cy.reload();

    // Second visit should be faster due to caching
    cy.window().then((win) => {
      win.performance.mark('second-visit');

      const navigation = win.performance.getEntriesByType('navigation')[0];
      expect(navigation.loadEventEnd - navigation.navigationStart).to.be.lessThan(2000);
    });
  });

  it('should handle network conditions gracefully', () => {
    // Simulate slow network
    cy.intercept('**/*', (req) => {
      req.reply((res) => {
        // Add delay to simulate slow network
        return new Promise((resolve) => {
          setTimeout(() => resolve(res), 1000);
        });
      });
    });

    cy.visit('/');

    // Should still load within reasonable time
    cy.get('.header').should('be.visible');
    cy.get('#stock-search-form').should('be.visible');
  });

  it('should optimize bundle size', () => {
    cy.request('GET', '/js/app.js').then((response) => {
      // Check bundle size
      const sizeKB = new Blob([response.body]).size / 1024;
      expect(sizeKB).to.be.lessThan(500); // Less than 500KB
    });
  });
});