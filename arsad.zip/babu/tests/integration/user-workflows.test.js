/**
 * Integration Tests for StockTicker Application
 * Tests component interactions and user workflows
 */

describe('StockTicker Integration', () => {
    let stockTicker;

    beforeEach(() => {
        // Setup full DOM
        document.body.innerHTML = `
            <header>
                <div id="active-stocks">0</div>
                <div id="market-status">Loading...</div>
                <div id="last-update">--:--</div>
            </header>
            <div id="ticker-content"></div>
            <form id="stock-search-form">
                <input id="stock-symbol-input" type="text" />
                <button type="submit">Add Stock</button>
            </form>
            <div id="search-message"></div>
            <div id="stock-grid"></div>
            <div id="popular-stocks"></div>
        `;

        // Initialize StockTicker
        const StockTickerClass = require('../../js/app.js').StockTicker;
        stockTicker = new StockTickerClass();
    });

    describe('User Workflows', () => {
        test('should complete add stock workflow', async () => {
            const input = document.getElementById('stock-symbol-input');
            const form = document.getElementById('stock-search-form');

            // Mock successful API response
            jest.spyOn(stockTicker, 'fetchStockData').mockResolvedValue({
                symbol: 'AAPL',
                name: 'Apple Inc.',
                price: 150.00,
                change: 2.50,
                changePercent: 1.70
            });

            // Simulate user input
            input.value = 'aapl';
            form.dispatchEvent(new Event('submit'));

            await global.testUtils.waitFor(() => stockTicker.stocks.has('AAPL'));

            expect(stockTicker.stocks.has('AAPL')).toBe(true);
            expect(document.getElementById('active-stocks').textContent).toBe('1');
        });

        test('should handle form submission with empty input', async () => {
            const form = document.getElementById('stock-search-form');
            const input = document.getElementById('stock-symbol-input');

            input.value = '';
            form.dispatchEvent(new Event('submit'));

            // Should not add any stocks
            expect(stockTicker.stocks.size).toBe(0);
        });

        test('should update UI when stock is added', async () => {
            jest.spyOn(stockTicker, 'createStockCard').mockImplementation((symbol) => {
                const grid = document.getElementById('stock-grid');
                const card = document.createElement('div');
                card.id = `stock-${symbol}`;
                card.innerHTML = `<div class="stock-symbol">${symbol}</div>`;
                grid.appendChild(card);
            });

            await stockTicker.addStock('TSLA');

            expect(document.getElementById('stock-TSLA')).toBeTruthy();
        });
    });

    describe('Real-time Updates', () => {
        test('should update stock prices periodically', async () => {
            // Add a stock
            const mockStock = global.testUtils.createMockStock('AAPL', 150);
            stockTicker.stocks.set('AAPL', mockStock);

            // Mock chart updates
            const mockChart = { update: jest.fn() };
            stockTicker.charts.set('AAPL', mockChart);

            // Mock DOM elements
            const card = document.createElement('div');
            card.id = 'stock-AAPL';
            card.innerHTML = `
                <div class="stock-price">$150.00</div>
                <div class="stock-change"></div>
            `;
            document.body.appendChild(card);

            // Start real-time updates
            stockTicker.startRealtimeUpdates('AAPL');

            // Wait for first update
            await new Promise(resolve => setTimeout(resolve, 100));

            expect(mockChart.update).toHaveBeenCalled();
        });
    });

    describe('Error Handling', () => {
        test('should show error for invalid stock symbol', async () => {
            jest.spyOn(stockTicker, 'fetchStockData').mockRejectedValue(new Error('Invalid symbol'));

            await stockTicker.addStock('INVALID');

            const messageContainer = document.getElementById('search-message');
            expect(messageContainer.innerHTML).toContain('error-message');
        });

        test('should retry failed API calls', async () => {
            let callCount = 0;
            jest.spyOn(stockTicker, 'fetchStockData').mockImplementation(() => {
                callCount++;
                if (callCount < 3) {
                    return Promise.reject(new Error('Network error'));
                }
                return Promise.resolve(global.testUtils.createMockStock('AAPL'));
            });

            await stockTicker.addStock('AAPL');

            expect(callCount).toBe(3);
            expect(stockTicker.stocks.has('AAPL')).toBe(true);
        });
    });

    describe('Performance', () => {
        test('should limit chart data points for performance', async () => {
            const mockStock = {
                ...global.testUtils.createMockStock('AAPL'),
                history: new Array(30).fill(150) // More than 20 points
            };

            stockTicker.stocks.set('AAPL', mockStock);

            const newData = global.testUtils.createMockStock('AAPL', 155);
            await stockTicker.addStock('AAPL'); // This will update the existing stock

            const updatedStock = stockTicker.stocks.get('AAPL');
            expect(updatedStock.history.length).toBeLessThanOrEqual(20);
        });

        test('should pause updates when page is hidden', () => {
            stockTicker.stocks.set('AAPL', global.testUtils.createMockStock('AAPL'));
            stockTicker.wsConnections.set('AAPL', setInterval(() => {}, 1000));

            const originalClearInterval = global.clearInterval;
            global.clearInterval = jest.fn();

            stockTicker.pauseUpdates();

            expect(global.clearInterval).toHaveBeenCalled();
            global.clearInterval = originalClearInterval;
        });
    });

    describe('Accessibility', () => {
        test('should have proper ARIA labels', () => {
            const input = document.getElementById('stock-symbol-input');
            expect(input.getAttribute('aria-label')).toBeTruthy();
        });

        test('should support keyboard navigation', () => {
            const form = document.getElementById('stock-search-form');
            const input = document.getElementById('stock-symbol-input');

            // Test Enter key submission
            input.value = 'AAPL';
            const enterEvent = new KeyboardEvent('keydown', { key: 'Enter', ctrlKey: true });
            document.dispatchEvent(enterEvent);

            // Should trigger form submission
            expect(input.value).toBe('AAPL');
        });
    });
});